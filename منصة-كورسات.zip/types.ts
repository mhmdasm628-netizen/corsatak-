// Fix: Define all necessary types for the application

export type Role = 'student' | 'admin';
export type Permission = 'manage_courses' | 'manage_forums' | 'manage_users';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: Role;
  permissions: Permission[];
}

export type LessonType = 'video' | 'reading' | 'quiz';

export interface Lesson {
  id: string;
  title: string;
  type: LessonType;
  content: string; // URL for video, markdown for reading, or quiz ID
  durationMinutes: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface Quiz {
  id: string;
  lessonId: string;
  questions: QuizQuestion[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  category: string;
  imageUrl: string;
  price: number;
  lessons: Lesson[];
}

export interface Enrollment {
  userId: string;
  courseId: string;
  progress: {
    completedLessons: string[]; // array of lesson IDs
  };
  enrollmentDate: Date;
}

export type PaymentRequestStatus = 'pending' | 'approved' | 'rejected';

export interface PaymentRequest {
  id: string;
  userId: string;
  courseId: string;
  paymentPhoneNumber: string;
  status: PaymentRequestStatus;
  requestDate: Date;
}

export interface AppSettings {
  vodafoneCashNumber: string;
}

export interface ForumReply {
  id: string;
  postId: string;
  authorId: string;
  content: string;
  createdAt: Date;
}

export interface ForumPost {
  id: string;
  courseId: string;
  authorId: string;
  title: string;
  content: string;
  createdAt: Date;
  replies: ForumReply[];
}