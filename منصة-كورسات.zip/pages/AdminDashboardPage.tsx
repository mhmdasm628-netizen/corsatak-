// Fix: Implement the AdminDashboardPage component
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { Course, Permission, User, Lesson, LessonType } from '../types';
import Button from '../components/Button';
import Modal from '../components/Modal';
import Input from '../components/Input';
import PlusIcon from '../components/icons/PlusIcon';
import CogIcon from '../components/icons/CogIcon';
import DocumentArrowDownIcon from '../components/icons/DocumentArrowDownIcon';
import BookOpenIcon from '../components/icons/BookOpenIcon';
import PencilIcon from '../components/icons/PencilIcon';
import TrashIcon from '../components/icons/TrashIcon';
import UsersIcon from '../components/icons/UsersIcon';

// Permissions Modal Component
const PermissionsModal: React.FC<{ user: User, onClose: () => void }> = ({ user, onClose }) => {
    const { updateUserPermissions, hasPermission } = useAppContext();
    const allPermissions: Permission[] = ['manage_courses', 'manage_forums', 'manage_users'];
    const [selectedPermissions, setSelectedPermissions] = useState<Permission[]>(user.permissions);

    const handleTogglePermission = (permission: Permission) => {
        setSelectedPermissions(prev => 
            prev.includes(permission) ? prev.filter(p => p !== permission) : [...prev, permission]
        );
    };

    const handleSave = () => {
        updateUserPermissions(user.id, selectedPermissions);
        onClose();
    };

    return (
        <Modal isOpen={true} onClose={onClose} title={`تعديل صلاحيات ${user.name}`}>
            <div className="space-y-4">
                {allPermissions.map(p => (
                    <div key={p} className="flex items-center">
                        <input 
                            type="checkbox"
                            id={`perm-${p}`}
                            checked={selectedPermissions.includes(p)}
                            onChange={() => handleTogglePermission(p)}
                            className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        />
                         <label htmlFor={`perm-${p}`} className="mr-3 block text-sm font-medium text-gray-700">{p}</label>
                    </div>
                ))}
            </div>
            <div className="flex justify-end gap-2 pt-6">
                <Button type="button" variant="secondary" onClick={onClose}>إلغاء</Button>
                <Button onClick={handleSave} disabled={!hasPermission('manage_users')}>حفظ</Button>
            </div>
        </Modal>
    );
};

// Course Editor Component
const CourseEditor: React.FC<{ course: Course, onBack: () => void }> = ({ course, onBack }) => {
    const { updateCourse, addLessonToCourse, updateLessonInCourse, deleteLessonFromCourse } = useAppContext();
    const [form, setForm] = useState(course);
    const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
    const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);

    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: name === 'price' ? Number(value) : value }));
    };

    const handleSaveCourse = () => {
        updateCourse(form);
        alert('تم حفظ بيانات الدورة!');
    };
    
    const openAddLessonModal = () => {
        setEditingLesson(null);
        setIsLessonModalOpen(true);
    };

    const openEditLessonModal = (lesson: Lesson) => {
        setEditingLesson(lesson);
        setIsLessonModalOpen(true);
    };
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <Button onClick={onBack} variant="secondary" className="mb-4">&larr; العودة إلى لوحة التحكم</Button>
            <h2 className="text-2xl font-bold mb-4">تعديل الدورة: {course.title}</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input label="عنوان الدورة" name="title" value={form.title} onChange={handleFormChange} />
                <Input label="المحاضر" name="instructor" value={form.instructor} onChange={handleFormChange} />
                <Input label="الفئة" name="category" value={form.category} onChange={handleFormChange} />
                <Input label="السعر" name="price" type="number" value={form.price} onChange={handleFormChange} />
                <div className="md:col-span-2">
                    <Input label="رابط الصورة" name="imageUrl" value={form.imageUrl} onChange={handleFormChange} />
                </div>
                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">الوصف</label>
                    <textarea name="description" value={form.description} onChange={handleFormChange} rows={4} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                </div>
            </div>
            <Button onClick={handleSaveCourse} className="mt-4">حفظ بيانات الدورة</Button>

            <hr className="my-6" />

            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">دروس الدورة</h3>
                <Button onClick={openAddLessonModal} size="sm"><PlusIcon className="h-4 w-4 mr-1"/> إضافة درس</Button>
            </div>
            <div className="space-y-2">
                {form.lessons.map(lesson => (
                    <div key={lesson.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>{lesson.title} ({lesson.type})</span>
                        <div className="flex gap-2">
                            <Button onClick={() => openEditLessonModal(lesson)} variant="secondary" size="sm" className="p-1"><PencilIcon className="h-4 w-4"/></Button>
                            <Button onClick={() => deleteLessonFromCourse(course.id, lesson.id)} variant="danger" size="sm" className="p-1"><TrashIcon className="h-4 w-4"/></Button>
                        </div>
                    </div>
                ))}
            </div>
             {isLessonModalOpen && <LessonModal courseId={course.id} lesson={editingLesson} onClose={() => setIsLessonModalOpen(false)} />}
        </div>
    );
};

// Lesson Modal Component
const LessonModal: React.FC<{ courseId: string, lesson: Lesson | null, onClose: () => void }> = ({ courseId, lesson, onClose }) => {
    const { addLessonToCourse, updateLessonInCourse } = useAppContext();
    const [form, setForm] = useState({
        title: lesson?.title || '',
        type: lesson?.type || 'video',
        content: lesson?.content || '',
        durationMinutes: lesson?.durationMinutes || 0,
    });
    
    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: name === 'durationMinutes' ? Number(value) : value }));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (lesson) {
            updateLessonInCourse(courseId, { ...lesson, ...form });
        } else {
            addLessonToCourse(courseId, form);
        }
        onClose();
    };

    return (
        <Modal isOpen={true} onClose={onClose} title={lesson ? 'تعديل الدرس' : 'إضافة درس جديد'}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <Input label="عنوان الدرس" name="title" value={form.title} onChange={handleFormChange} required />
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">نوع الدرس</label>
                    <select name="type" value={form.type} onChange={handleFormChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
                        <option value="video">فيديو</option>
                        <option value="reading">قراءة</option>
                        <option value="quiz">اختبار</option>
                    </select>
                </div>
                <Input label="المحتوى (رابط أو نص)" name="content" value={form.content} onChange={handleFormChange} required />
                <Input label="المدة (دقائق)" name="durationMinutes" type="number" value={form.durationMinutes} onChange={handleFormChange} required />
                <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="secondary" onClick={onClose}>إلغاء</Button>
                    <Button type="submit">{lesson ? 'حفظ التغييرات' : 'إضافة الدرس'}</Button>
                </div>
            </form>
        </Modal>
    );
};

// Add Course Modal Component
const AddCourseModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { addCourse } = useAppContext();
    const [form, setForm] = useState({
        title: '',
        description: '',
        instructor: '',
        category: '',
        imageUrl: '',
        price: 0,
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: name === 'price' ? Number(value) : value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (form.title && form.instructor && form.category) {
            addCourse({ ...form, lessons: [] });
            onClose();
        } else {
            alert("يرجى ملء الحقول الأساسية: العنوان، المحاضر، والفئة.");
        }
    };
    
    return (
        <Modal isOpen={true} onClose={onClose} title="إضافة دورة جديدة">
            <form onSubmit={handleSubmit} className="space-y-4">
                <Input label="عنوان الدورة" name="title" value={form.title} onChange={handleChange} required />
                <Input label="المحاضر" name="instructor" value={form.instructor} onChange={handleChange} required />
                <Input label="الفئة" name="category" value={form.category} onChange={handleChange} required />
                <Input label="السعر" name="price" type="number" value={form.price} onChange={handleChange} required />
                <Input label="رابط الصورة" name="imageUrl" value={form.imageUrl} onChange={handleChange} />
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">الوصف</label>
                    <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                </div>
                <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="secondary" onClick={onClose}>إلغاء</Button>
                    <Button type="submit">إضافة الدورة</Button>
                </div>
            </form>
        </Modal>
    );
};


interface AdminDashboardPageProps {
  viewCourse: (course: Course) => void;
}

type AdminTab = 'courses' | 'payments' | 'settings' | 'users';

const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ viewCourse }) => {
    const { user, courses, getUsers, addCourse, deleteCourse, paymentRequests, settings, updatePaymentRequestStatus, updateVodafoneCashNumber, hasPermission } = useAppContext();
    
    const [activeTab, setActiveTab] = useState<AdminTab>('courses');
    const [editingCourse, setEditingCourse] = useState<Course | null>(null);
    const [managingUser, setManagingUser] = useState<User | null>(null);
    const [isAddCourseModalOpen, setIsAddCourseModalOpen] = useState(false);
    const [vodafoneNumber, setVodafoneNumber] = useState(settings.vodafoneCashNumber);

    const users = getUsers();
    
    useEffect(() => {
        if (!hasPermission('manage_courses')) setActiveTab('payments');
    }, []);

    if (!user || (user.role !== 'admin' && user.permissions.length === 0)) {
        return <p className="text-center text-red-500">ليس لديك صلاحية الوصول لهذه الصفحة.</p>;
    }

    if (editingCourse) {
        const courseData = courses.find(c => c.id === editingCourse.id);
        if (!courseData) { setEditingCourse(null); return null; }
        return <CourseEditor course={courseData} onBack={() => setEditingCourse(null)} />;
    }
    
    const getCourseTitle = (courseId: string) => courses.find(c => c.id === courseId)?.title || 'دورة محذوفة';
    const getUserName = (userId: string) => users.find(u => u.id === userId)?.name || 'مستخدم محذوف';
    
    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">لوحة تحكم المشرف</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white p-6 rounded-lg shadow-md"><h3 className="text-xl font-semibold">إجمالي الدورات</h3><p className="text-4xl font-bold text-primary-600">{courses.length}</p></div>
                <div className="bg-white p-6 rounded-lg shadow-md"><h3 className="text-xl font-semibold">إجمالي المستخدمين</h3><p className="text-4xl font-bold text-primary-600">{users.length}</p></div>
                <div className="bg-white p-6 rounded-lg shadow-md"><h3 className="text-xl font-semibold">الطلبات المعلقة</h3><p className="text-4xl font-bold text-primary-600">{paymentRequests.filter(p => p.status === 'pending').length}</p></div>
            </div>

            <div className="mb-6 border-b border-gray-200">
                <nav className="flex -mb-px gap-6" aria-label="Tabs">
                    {hasPermission('manage_courses') && <button onClick={() => setActiveTab('courses')} className={`py-4 px-1 inline-flex items-center gap-2 border-b-2 text-sm font-medium ${activeTab === 'courses' ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}><BookOpenIcon className="h-5 w-5" /> الدورات</button>}
                    <button onClick={() => setActiveTab('payments')} className={`py-4 px-1 inline-flex items-center gap-2 border-b-2 text-sm font-medium ${activeTab === 'payments' ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}><DocumentArrowDownIcon className="h-5 w-5" /> طلبات الدفع</button>
                    {hasPermission('manage_users') && <button onClick={() => setActiveTab('users')} className={`py-4 px-1 inline-flex items-center gap-2 border-b-2 text-sm font-medium ${activeTab === 'users' ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}><UsersIcon className="h-5 w-5" /> المستخدمون</button>}
                    {user.role === 'admin' && <button onClick={() => setActiveTab('settings')} className={`py-4 px-1 inline-flex items-center gap-2 border-b-2 text-sm font-medium ${activeTab === 'settings' ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}><CogIcon className="h-5 w-5" /> الإعدادات</button>}
                </nav>
            </div>
            
            {activeTab === 'courses' && hasPermission('manage_courses') && (
                 <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-bold">إدارة الدورات</h2>
                        <Button onClick={() => setIsAddCourseModalOpen(true)}><PlusIcon className="h-5 w-5 mr-2"/> إضافة دورة</Button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-right text-gray-500">
                           <thead className="text-xs text-gray-700 uppercase bg-gray-50"><tr><th className="px-6 py-3">العنوان</th><th className="px-6 py-3">الإجراءات</th></tr></thead>
                            <tbody>{courses.map(c => <tr key={c.id} className="bg-white border-b"><th className="px-6 py-4 font-medium text-gray-900">{c.title}</th><td className="px-6 py-4 flex gap-2"><Button onClick={() => setEditingCourse(c)} variant="secondary" size="sm">تعديل</Button><Button onClick={() => deleteCourse(c.id)} variant="danger" size="sm">حذف</Button></td></tr>))}</tbody>
                        </table>
                    </div>
                </div>
            )}
            
            {activeTab === 'payments' && (
                 <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-2xl font-bold mb-4">طلبات الدفع</h2>
                    <div className="overflow-x-auto">
                        {paymentRequests.length > 0 ? (
                            <table className="w-full text-sm text-right text-gray-500">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3">اسم الطالب</th>
                                        <th className="px-6 py-3">الدورة</th>
                                        <th className="px-6 py-3">الرقم المحول منه</th>
                                        <th className="px-6 py-3">تاريخ الطلب</th>
                                        <th className="px-6 py-3">الحالة</th>
                                        <th className="px-6 py-3">الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paymentRequests.map(req => (
                                        <tr key={req.id} className="bg-white border-b">
                                            <td className="px-6 py-4">{getUserName(req.userId)}</td>
                                            <td className="px-6 py-4">{getCourseTitle(req.courseId)}</td>
                                            <td className="px-6 py-4 font-mono">{req.paymentPhoneNumber}</td>
                                            <td className="px-6 py-4">{new Date(req.requestDate).toLocaleDateString()}</td>
                                            <td className="px-6 py-4">{req.status}</td>
                                            <td className="px-6 py-4">
                                                {req.status === 'pending' && (
                                                    <div className="flex gap-2">
                                                        <Button onClick={() => updatePaymentRequestStatus(req.id, 'approved')} size="sm">قبول</Button>
                                                        <Button onClick={() => updatePaymentRequestStatus(req.id, 'rejected')} variant="danger" size="sm">رفض</Button>
                                                    </div>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            <p className="text-center text-gray-500 py-4">لا توجد طلبات دفع حاليًا.</p>
                        )}
                    </div>
                </div>
            )}
            
            {activeTab === 'users' && hasPermission('manage_users') && (
                 <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-2xl font-bold mb-4">إدارة المستخدمين</h2>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-right text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50"><tr><th className="px-6 py-3">الاسم</th><th className="px-6 py-3">البريد الإلكتروني</th><th className="px-6 py-3">الصلاحيات</th><th className="px-6 py-3">الإجراءات</th></tr></thead>
                            <tbody>{users.filter(u => u.id !== user.id).map(u => <tr key={u.id} className="bg-white border-b"><td className="px-6 py-4">{u.name}</td><td className="px-6 py-4">{u.email}</td><td className="px-6 py-4">{u.permissions.join(', ') || 'لا يوجد'}</td><td className="px-6 py-4"><Button onClick={() => setManagingUser(u)} variant="secondary" size="sm">تعديل الصلاحيات</Button></td></tr>)}</tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'settings' && user.role === 'admin' && (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-2xl font-bold mb-4">إعدادات الدفع</h2>
                    <div className="max-w-md"><Input label="رقم فودافون كاش" id="vodafoneNumber" value={vodafoneNumber} onChange={(e) => setVodafoneNumber(e.target.value)} /><Button onClick={() => { updateVodafoneCashNumber(vodafoneNumber); alert('تم الحفظ!'); }} className="mt-4">حفظ</Button></div>
                </div>
            )}

            {managingUser && <PermissionsModal user={managingUser} onClose={() => setManagingUser(null)} />}
            {isAddCourseModalOpen && <AddCourseModal onClose={() => setIsAddCourseModalOpen(false)} />}
        </div>
    );
};

export default AdminDashboardPage;