// Fix: Implement the UserDashboardPage component
import React from 'react';
import { useAppContext } from '../context/AppContext';
import { Course } from '../types';
import CourseCard from '../components/CourseCard';
import UsersIcon from '../components/icons/UsersIcon';

interface UserDashboardPageProps {
  viewCourse: (course: Course) => void;
}

const UserDashboardPage: React.FC<UserDashboardPageProps> = ({ viewCourse }) => {
  const { user, enrollments, courses } = useAppContext();

  if (!user) {
    return <p className="text-center text-gray-500">الرجاء تسجيل الدخول لعرض لوحة التحكم الخاصة بك.</p>;
  }

  const userEnrollments = enrollments.filter(e => e.userId === user.id);
  const enrolledCourses = userEnrollments.map(e => {
    const course = courses.find(c => c.id === e.courseId);
    if (!course) return null;

    const completedCount = e.progress.completedLessons.length;
    const totalLessons = course.lessons.length;
    const progressPercentage = totalLessons > 0 ? (completedCount / totalLessons) * 100 : 0;

    return { ...course, progress: progressPercentage };
  }).filter(Boolean) as (Course & { progress: number })[];

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-6">مرحباً بعودتك، {user.name}!</h1>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h2 className="text-2xl font-bold mb-4">دوراتي المسجلة</h2>
        {enrolledCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {enrolledCourses.map(course => (
              <div key={course.id} className="relative">
                 <CourseCard course={course} onViewCourse={viewCourse} />
                 <div className="absolute top-4 right-4 bg-white p-2 rounded-md shadow">
                    <p className="text-sm font-semibold">التقدم: {Math.round(course.progress)}%</p>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                        <div className="bg-primary-600 h-1.5 rounded-full" style={{ width: `${course.progress}%` }}></div>
                    </div>
                 </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-10">
            <UsersIcon className="h-12 w-12 mx-auto text-gray-400" />
            <p className="mt-4 text-gray-500">لم تسجل في أي دورات بعد.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboardPage;
