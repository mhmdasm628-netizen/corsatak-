// Fix: Implement the HomePage component
import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Course } from '../types';
import CourseCard from '../components/CourseCard';
import Input from '../components/Input';

interface HomePageProps {
  viewCourse: (course: Course) => void;
}

const HomePage: React.FC<HomePageProps> = ({ viewCourse }) => {
  const { courses } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', ...Array.from(new Set(courses.map(c => c.category)))];

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          course.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div>
      <section className="text-center py-10 bg-white rounded-lg shadow-md mb-8">
        <h1 className="text-4xl font-extrabold text-gray-800">اكتشف مستقبلك</h1>
        <p className="text-lg text-gray-600 mt-4 max-w-2xl mx-auto">
          انضم إلى آلاف المتعلمين حول العالم. تعلم بالسرعة التي تناسبك.
        </p>
      </section>

      <div className="mb-8 p-4 bg-white rounded-lg shadow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
                <Input 
                    id="search"
                    type="text"
                    placeholder="ابحث عن دورة..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <div>
                <select 
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                >
                    {categories.map(cat => (
                        <option key={cat} value={cat}>{cat === 'all' ? 'كل الفئات' : cat}</option>
                    ))}
                </select>
            </div>
          </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredCourses.length > 0 ? (
          filteredCourses.map(course => (
            <CourseCard key={course.id} course={course} onViewCourse={viewCourse} />
          ))
        ) : (
          <p className="text-center col-span-full text-gray-500">لا توجد دورات تطابق بحثك.</p>
        )}
      </div>
    </div>
  );
};

export default HomePage;
