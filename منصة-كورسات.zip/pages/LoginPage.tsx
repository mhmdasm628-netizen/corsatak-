// Fix: Implement LoginPage component
import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import Input from '../components/Input';
import Button from '../components/Button';

interface LoginPageProps {
    onLoginSuccess: () => void;
}

type AuthMode = 'login' | 'signup';

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const { login, signup } = useAppContext();
  
  const [mode, setMode] = useState<AuthMode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    if (login({ email, password })) {
      onLoginSuccess();
    } else {
      setError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
    }
    setIsSubmitting(false);
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    const result = signup({ name, email, password });
    if (result.success) {
      onLoginSuccess();
    } else {
      setError(result.message);
    }
    setIsSubmitting(false);
  };
  
  const toggleMode = () => {
    setMode(prev => (prev === 'login' ? 'signup' : 'login'));
    setError('');
    setName('');
    setEmail('');
    setPassword('');
  };

  return (
    <div className="flex justify-center items-center py-12">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">
          {mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
        </h2>
        
        <form onSubmit={mode === 'login' ? handleLoginSubmit : handleSignupSubmit}>
          {mode === 'signup' && (
            <div className="mb-4">
              <Input 
                label="الاسم الكامل"
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: أحمد علي"
                required
                disabled={isSubmitting}
              />
            </div>
          )}
          <div className="mb-4">
            <Input 
              label="البريد الإلكتروني"
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="example@example.com"
              required
              disabled={isSubmitting}
            />
          </div>
          <div className="mb-6">
            <Input 
              label="كلمة المرور"
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="********"
              required
              disabled={isSubmitting}
            />
          </div>
          
          {error && <p className="text-red-500 text-sm mb-4 text-center">{error}</p>}
          
          <Button type="submit" variant="primary" className="w-full" disabled={isSubmitting}>
            {isSubmitting 
                ? 'جاري المعالجة...' 
                : mode === 'login' ? 'تسجيل الدخول' : 'إنشاء الحساب'}
          </Button>
        </form>

        <p className="text-center text-sm text-gray-600 mt-6">
          {mode === 'login' ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}
          <button onClick={toggleMode} className="font-semibold text-primary-600 hover:text-primary-500 mr-2">
            {mode === 'login' ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
