// Fix: Implement the CourseDetailPage component
import React, { useState } from 'react';
import { Course, Lesson, ForumPost as ForumPostType } from '../types';
import { useAppContext } from '../context/AppContext';
import Button from '../components/Button';
import CheckCircleIcon from '../components/icons/CheckCircleIcon';
import VideoCameraIcon from '../components/icons/VideoCameraIcon';
import DocumentTextIcon from '../components/icons/DocumentTextIcon';
import ChatBubbleIcon from '../components/icons/ChatBubbleIcon';
import Modal from '../components/Modal';
import Input from '../components/Input';
import TrashIcon from '../components/icons/TrashIcon';

// Forum Component
const Forum: React.FC<{ courseId: string }> = ({ courseId }) => {
    const { user, getUsers, getForumPostsForCourse, addForumPost, addForumReply, deleteForumPost, deleteForumReply, hasPermission } = useAppContext();
    const [isPostModalOpen, setIsPostModalOpen] = useState(false);
    const [newPost, setNewPost] = useState({ title: '', content: '' });
    const [replyContent, setReplyContent] = useState<{ [key: string]: string }>({});

    const posts = getForumPostsForCourse(courseId);
    const users = getUsers();
    const getUserName = (id: string) => users.find(u => u.id === id)?.name || "مستخدم محذوف";

    const handlePostSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addForumPost({ courseId, ...newPost });
        setNewPost({ title: '', content: '' });
        setIsPostModalOpen(false);
    };

    const handleReplySubmit = (postId: string) => {
        const content = replyContent[postId];
        if (!content) return;
        addForumReply({ postId, content });
        setReplyContent(prev => ({...prev, [postId]: ''}));
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold">المنتدى</h3>
                <Button onClick={() => setIsPostModalOpen(true)}>مشاركة جديدة</Button>
            </div>
            {posts.length > 0 ? posts.map(post => (
                <div key={post.id} className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between items-start">
                        <div>
                            <h4 className="font-bold text-lg">{post.title}</h4>
                            <p className="text-sm text-gray-500">بواسطة {getUserName(post.authorId)} - {new Date(post.createdAt).toLocaleDateString()}</p>
                        </div>
                        {(hasPermission('manage_forums') || user?.id === post.authorId) && (
                            <button onClick={() => deleteForumPost(post.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-5 h-5"/></button>
                        )}
                    </div>
                    <p className="mt-2 text-gray-700">{post.content}</p>
                    
                    {/* Replies */}
                    <div className="mt-4 space-y-3 pr-4 border-r-2 border-primary-200">
                        {post.replies.map(reply => (
                           <div key={reply.id} className="bg-white p-3 rounded-md">
                               <div className="flex justify-between items-start">
                                    <p className="text-sm text-gray-500">
                                        <strong>{getUserName(reply.authorId)}:</strong>
                                    </p>
                                    {(hasPermission('manage_forums') || user?.id === reply.authorId) && (
                                        <button onClick={() => deleteForumReply(post.id, reply.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-4 h-4"/></button>
                                    )}
                               </div>
                               <p className="text-gray-600">{reply.content}</p>
                           </div>
                        ))}
                         <div className="flex gap-2">
                            <Input 
                                placeholder="اكتب ردك هنا..." 
                                value={replyContent[post.id] || ''} 
                                onChange={e => setReplyContent(prev => ({ ...prev, [post.id]: e.target.value }))}
                                className="flex-grow"
                            />
                            <Button size="sm" onClick={() => handleReplySubmit(post.id)}>رد</Button>
                        </div>
                    </div>
                </div>
            )) : <p className="text-center text-gray-500 py-4">لا توجد مشاركات في المنتدى بعد. كن أول من يشارك!</p>}

            <Modal isOpen={isPostModalOpen} onClose={() => setIsPostModalOpen(false)} title="إنشاء مشاركة جديدة">
                <form onSubmit={handlePostSubmit} className="space-y-4">
                    <Input label="عنوان المشاركة" value={newPost.title} onChange={e => setNewPost({...newPost, title: e.target.value})} required />
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">المحتوى</label>
                        <textarea value={newPost.content} onChange={e => setNewPost({...newPost, content: e.target.value})} rows={4} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" required />
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                        <Button type="button" variant="secondary" onClick={() => setIsPostModalOpen(false)}>إلغاء</Button>
                        <Button type="submit">نشر</Button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

interface CourseDetailPageProps {
  course: Course;
  backToList: () => void;
}

const CourseDetailPage: React.FC<CourseDetailPageProps> = ({ course, backToList }) => {
    const { user, getEnrollmentForCourse, enrollInCourse, completeLesson, settings, paymentRequests, createPaymentRequest } = useAppContext();
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    const [paymentPhoneNumber, setPaymentPhoneNumber] = useState('');
    const [activeTab, setActiveTab] = useState<'content' | 'forum'>('content');
    
    const enrollment = getEnrollmentForCourse(course.id);
    const existingRequest = paymentRequests.find((pr) => pr.userId === user?.id && pr.courseId === course.id && pr.status === 'pending');

    const handleEnroll = () => {
        if (!user) { alert('الرجاء تسجيل الدخول أولاً للتسجيل في الدورة.'); return; }
        if (course.price > 0) {
            setPaymentPhoneNumber('');
            setIsPaymentModalOpen(true); 
        } 
        else { enrollInCourse(course.id); }
    };

    const handlePaymentRequest = () => {
        if (!paymentPhoneNumber.trim()) {
            alert('الرجاء إدخال الرقم الذي تم التحويل منه.');
            return;
        }
        createPaymentRequest(course.id, paymentPhoneNumber);
        setIsPaymentModalOpen(false);
        setPaymentPhoneNumber('');
    };

    const getLessonIcon = (type: Lesson['type']) => {
        switch (type) {
            case 'video': return <VideoCameraIcon className="h-5 w-5 text-primary-600" />;
            case 'reading': return <DocumentTextIcon className="h-5 w-5 text-indigo-600" />;
            case 'quiz': return <ChatBubbleIcon className="h-5 w-5 text-amber-600" />;
            default: return null;
        }
    };

    const totalDuration = course.lessons.reduce((sum, lesson) => sum + lesson.durationMinutes, 0);

    return (
        <div>
            <Button onClick={backToList} variant="secondary" className="mb-6">&rarr; العودة إلى كل الدورات</Button>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">{course.title}</h1>
                    <p className="text-gray-500 mb-4">بواسطة {course.instructor}</p>
                    <p className="text-gray-700 leading-relaxed">{course.description}</p>
                </div>
                <div className="row-start-1 lg:row-auto">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <img src={course.imageUrl} alt={course.title} className="w-full rounded-md mb-4" />
                        <p className="text-3xl font-bold text-primary-600 mb-4 text-center">{course.price > 0 ? `${course.price} ر.س` : 'مجاني'}</p>
                        {enrollment ? (
                             <div className="text-center p-3 bg-green-100 text-green-800 rounded-md">أنت مسجل في هذه الدورة.</div>
                        ) : existingRequest ? (
                            <Button className="w-full" disabled>طلبك قيد المراجعة</Button>
                        ) : (
                            <Button onClick={handleEnroll} className="w-full" disabled={!user}>{user ? 'سجل الآن' : 'سجل الدخول للتسجيل'}</Button>
                        )}
                        <div className="mt-4 text-sm text-gray-600 space-y-2">
                           <p><strong>المدة الإجمالية:</strong> {Math.floor(totalDuration / 60)} ساعة و {totalDuration % 60} دقيقة</p>
                           <p><strong>عدد الدروس:</strong> {course.lessons.length}</p>
                           <p><strong>الفئة:</strong> {course.category}</p>
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-3 bg-white p-6 rounded-lg shadow-md">
                    <div className="border-b border-gray-200 mb-4">
                        <nav className="flex -mb-px gap-6" aria-label="Tabs">
                             <button onClick={() => setActiveTab('content')} className={`py-4 px-1 border-b-2 text-sm font-medium ${activeTab === 'content' ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>محتوى الدورة</button>
                             {enrollment && <button onClick={() => setActiveTab('forum')} className={`py-4 px-1 border-b-2 text-sm font-medium ${activeTab === 'forum' ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>المنتدى</button>}
                        </nav>
                    </div>

                    {activeTab === 'content' && (
                        <ul className="space-y-3">
                            {course.lessons.map(lesson => {
                                const isCompleted = enrollment?.progress.completedLessons.includes(lesson.id);
                                return (
                                    <li key={lesson.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                                        <div className="flex items-center gap-3">
                                            {getLessonIcon(lesson.type)}
                                            <span>{lesson.title}</span>
                                            <span className="text-xs text-gray-500">({lesson.durationMinutes} دقيقة)</span>
                                        </div>
                                        {enrollment && (
                                            <button onClick={() => completeLesson(course.id, lesson.id)} disabled={isCompleted} className={`p-1 rounded-full ${isCompleted ? 'text-green-500' : 'text-gray-300 hover:text-green-500'}`}>
                                                <CheckCircleIcon className="h-6 w-6" />
                                            </button>
                                        )}
                                    </li>
                                );
                            })}
                        </ul>
                    )}

                    {activeTab === 'forum' && enrollment && <Forum courseId={course.id} />}
                </div>
            </div>
            <Modal isOpen={isPaymentModalOpen} onClose={() => setIsPaymentModalOpen(false)} title="إتمام عملية الدفع">
                <div className="space-y-4">
                    <div className="text-center">
                        <h3 className="text-lg font-semibold">للتسجيل في الدورة، يرجى تحويل مبلغ {course.price} ر.س إلى رقم فودافون كاش التالي:</h3>
                        <p className="text-2xl font-bold text-primary-600 bg-primary-50 p-3 rounded-md my-2">{settings.vodafoneCashNumber}</p>
                    </div>
                    <div className="text-right">
                        <Input 
                            label="الرقم الذي تم التحويل منه"
                            id="paymentPhoneNumber"
                            type="tel"
                            placeholder="مثال: 01012345678"
                            value={paymentPhoneNumber}
                            onChange={(e) => setPaymentPhoneNumber(e.target.value)}
                            required
                        />
                    </div>
                    <p className="text-sm text-gray-600 text-center">بعد إتمام عملية التحويل، اضغط على الزر أدناه لتأكيد الدفع وسيتم مراجعة طلبك من قبل الإدارة.</p>
                    <div className="flex justify-end gap-2 pt-4">
                        <Button type="button" variant="secondary" onClick={() => setIsPaymentModalOpen(false)}>إلغاء</Button>
                        <Button onClick={handlePaymentRequest}>تأكيد الدفع وإرسال الطلب</Button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default CourseDetailPage;