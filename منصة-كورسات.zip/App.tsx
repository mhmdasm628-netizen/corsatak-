// Fix: Implement the main App component with routing
import React, { useState, useEffect } from 'react';
import { AppProvider, useAppContext } from './context/AppContext';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import CourseDetailPage from './pages/CourseDetailPage';
import UserDashboardPage from './pages/UserDashboardPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import { Course } from './types';

type View = 'home' | 'login' | 'course' | 'dashboard' | 'admin';

const ThemedApp: React.FC = () => {
  const { themeColor } = useAppContext();
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  useEffect(() => {
    document.documentElement.style.setProperty('--primary-color', themeColor);
  }, [themeColor]);

  const viewCourse = (course: Course) => {
    setSelectedCourse(course);
    setCurrentView('course');
  };
  
  const navigate = (view: View) => {
    setCurrentView(view);
  }

  const renderContent = () => {
    switch (currentView) {
      case 'login':
        return <LoginPage onLoginSuccess={() => navigate('home')} />;
      case 'course':
        return selectedCourse ? <CourseDetailPage course={selectedCourse} backToList={() => navigate('home')} /> : <HomePage viewCourse={viewCourse} />;
      case 'dashboard':
        return <UserDashboardPage viewCourse={viewCourse} />;
      case 'admin':
          return <AdminDashboardPage viewCourse={viewCourse} />;
      case 'home':
      default:
        return <HomePage viewCourse={viewCourse} />;
    }
  };
  
  return (
    <div className="bg-gray-50 min-h-screen font-sans" dir="rtl">
      <Header navigate={navigate} />
      <main className="container mx-auto p-4 md:p-8">
        {renderContent()}
      </main>
    </div>
  );
}

const App: React.FC = () => {
  return (
    <AppProvider>
      <ThemedApp />
    </AppProvider>
  );
};

export default App;