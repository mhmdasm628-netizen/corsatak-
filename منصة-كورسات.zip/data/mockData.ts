// Fix: Provide mock data for the application
import { User, Course, Enrollment, PaymentRequest, AppSettings, ForumPost, Quiz } from '../types';

export const mockUsers: User[] = [
  { id: '1', name: 'أحمد علي', email: 'student@example.com', role: 'student', password: 'password123', permissions: [] },
  { id: '2', name: 'مشرف النظام', email: 'mhmdasm628@gmail.com', role: 'admin', password: 'mhmd2009@', permissions: ['manage_courses', 'manage_forums', 'manage_users'] },
];

export const mockCourses: Course[] = [
  {
    id: 'c1',
    title: 'مقدمة في البرمجة بلغة Python',
    description: 'دورة شاملة للمبتدئين لتعلم أساسيات البرمجة باستخدام لغة Python، واحدة من أكثر اللغات شعبية في العالم.',
    instructor: 'د. خالد العمري',
    category: 'البرمجة',
    imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2070&auto=format&fit=crop',
    price: 100,
    lessons: [
      { id: 'l1-1', title: 'مقدمة عن Python', type: 'video', content: 'https://www.youtube.com/embed/dQw4w9WgXcQ', durationMinutes: 15 },
      { id: 'l1-2', title: 'المتغيرات وأنواع البيانات', type: 'reading', content: '## المتغيرات\n\nالمتغيرات هي حاويات لتخزين قيم البيانات.', durationMinutes: 20 },
      { id: 'l1-3', title: 'اختبار قصير: الأساسيات', type: 'quiz', content: 'q1', durationMinutes: 10 },
    ],
  },
  {
    id: 'c2',
    title: 'أساسيات تصميم واجهات المستخدم (UI/UX)',
    description: 'تعلم مبادئ تصميم الواجهات وتجربة المستخدم لإنشاء تطبيقات ومواقع ويب جذابة وسهلة الاستخدام.',
    instructor: 'أ. سارة محمود',
    category: 'التصميم',
    imageUrl: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?q=80&w=2070&auto=format&fit=crop',
    price: 150,
    lessons: [
        { id: 'l2-1', title: 'ما هو UI/UX؟', type: 'video', content: 'https://www.youtube.com/embed/dQw4w9WgXcQ', durationMinutes: 18 },
        { id: 'l2-2', title: 'مبادئ التصميم الأساسية', type: 'reading', content: '## مبادئ التصميم\n\nالتباين، التكرار، المحاذاة، القرب.', durationMinutes: 25 },
        { id: 'l2-3', title: 'بحث المستخدم', type: 'video', content: 'https://www.youtube.com/embed/dQw4w9WgXcQ', durationMinutes: 22 },
    ],
  },
    {
    id: 'c3',
    title: 'التسويق الرقمي المتقدم',
    description: 'استكشف استراتيجيات التسويق الرقمي المتقدمة، بما في ذلك تحسين محركات البحث، والتسويق عبر وسائل التواصل الاجتماعي، والتسويق بالمحتوى.',
    instructor: 'م. عمر ياسين',
    category: 'التسويق',
    imageUrl: 'https://images.unsplash.com/photo-1557862921-37829c790f19?q=80&w=2071&auto=format&fit=crop',
    price: 0,
    lessons: [
        { id: 'l3-1', title: 'مقدمة في التسويق الرقمي', type: 'video', content: 'https://www.youtube.com/embed/dQw4w9WgXcQ', durationMinutes: 12 },
        { id: 'l3-2', title: 'تحسين محركات البحث (SEO)', type: 'reading', content: '## SEO\n\nتحسين محركات البحث هو عملية تحسين موقعك للحصول على ترتيب أعلى في نتائج البحث.', durationMinutes: 30 },
    ],
  },
];

export const mockEnrollments: Enrollment[] = [
    { 
        userId: '1', 
        courseId: 'c1', 
        progress: { completedLessons: ['l1-1'] },
        enrollmentDate: new Date('2023-09-01')
    },
];

export const mockPaymentRequests: PaymentRequest[] = [];

export const mockSettings: AppSettings = {
  vodafoneCashNumber: '01000000000' // Default number
};

export const mockForumPosts: ForumPost[] = [
    {
        id: 'p1',
        courseId: 'c1',
        authorId: '1',
        title: 'سؤال بخصوص المتغيرات',
        content: 'لم أفهم الفرق بين المتغيرات المحلية والعامة، هل يمكن لأحد أن يشرح؟',
        createdAt: new Date(),
        replies: [
            {
                id: 'r1',
                postId: 'p1',
                authorId: '2',
                content: 'أهلاً بك! المتغيرات المحلية تُعرّف داخل دالة ولا يمكن الوصول إليها خارجها، بينما المتغيرات العامة يمكن الوصول إليها من أي مكان في البرنامج. أتمنى أن يكون هذا واضحاً!',
                createdAt: new Date(),
            }
        ]
    }
];

export const mockQuizzes: Quiz[] = [
    {
        id: 'q1',
        lessonId: 'l1-3',
        questions: [
            {
                id: 'qq1',
                question: 'ما هي الكلمة الرئيسية لطباعة شيء ما في Python؟',
                options: ['console.log', 'print', 'echo', 'display'],
                correctAnswer: 'print'
            }
        ]
    }
];