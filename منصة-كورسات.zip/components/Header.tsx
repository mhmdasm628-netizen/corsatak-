// Fix: Implement the Header component
import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import UserIcon from './icons/UserIcon';
import BookOpenIcon from './icons/BookOpenIcon';
import PaletteIcon from './icons/PaletteIcon';
import Button from './Button';

type View = 'home' | 'login' | 'course' | 'dashboard' | 'admin';

interface HeaderProps {
    navigate: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ navigate }) => {
  const { user, logout, themeColor, setThemeColor } = useAppContext();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showThemePicker, setShowThemePicker] = useState(false);
  
  const colors = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#3b82f6'];

  const handleLogout = () => {
    logout();
    setShowUserMenu(false);
    navigate('home');
  };

  const canAccessAdmin = user && (user.role === 'admin' || user.permissions.length > 0);

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 md:px-8 py-4 flex justify-between items-center">
        <div 
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => navigate('home')}
        >
          <BookOpenIcon className="h-8 w-8 text-primary-600" />
          <h1 className="text-2xl font-bold text-gray-800">كورساتك</h1>
        </div>
        <nav className="flex items-center gap-4">
          <div className="relative">
            <button onClick={() => setShowThemePicker(!showThemePicker)} className="text-gray-600 hover:text-primary-600">
                <PaletteIcon className="h-6 w-6" />
            </button>
            {showThemePicker && (
                <div className="absolute left-0 mt-2 w-32 bg-white rounded-md shadow-lg p-2 z-20">
                    <p className="text-sm text-gray-500 mb-2">اختر لونًا:</p>
                    <div className="flex gap-2">
                        {colors.map(color => (
                            <button
                                key={color}
                                className={`w-6 h-6 rounded-full border-2 ${themeColor === color ? 'border-primary-700' : 'border-transparent'}`}
                                style={{ backgroundColor: color }}
                                onClick={() => {
                                    setThemeColor(color);
                                    setShowThemePicker(false);
                                }}
                            />
                        ))}
                    </div>
                </div>
            )}
          </div>

          {user ? (
            <div className="relative">
              <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center gap-2 text-gray-600">
                <UserIcon className="h-8 w-8 p-1 bg-gray-200 rounded-full" />
                <span className="hidden md:block">{user.name}</span>
              </button>
              {showUserMenu && (
                <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                  <button onClick={() => { navigate('dashboard'); setShowUserMenu(false); }} className="w-full text-right block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    لوحة التحكم
                  </button>
                  {canAccessAdmin && (
                     <button onClick={() => { navigate('admin'); setShowUserMenu(false); }} className="w-full text-right block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                       إدارة النظام
                     </button>
                  )}
                  <button onClick={handleLogout} className="w-full text-right block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    تسجيل الخروج
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Button onClick={() => navigate('login')}>
              تسجيل الدخول
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;