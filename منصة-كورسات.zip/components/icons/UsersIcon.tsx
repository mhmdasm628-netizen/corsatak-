// Fix: Provide SVG for UsersIcon
import React from 'react';

const UsersIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-6 w-6"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.25-1.264-.69-1.71M17 20V10c0-1.657-1.343-3-3-3s-3 1.343-3 3v10m-4-1a3 3 0 00-3-3H7a3 3 0 00-3 3v2h5m-5-2v-2a3 3 0 013-3h1m-1 5h.01M12 7a3 3 0 11-6 0 3 3 0 016 0zm-3 3a3 3 0 100-6 3 3 0 000 6z" />
  </svg>
);

export default UsersIcon;
