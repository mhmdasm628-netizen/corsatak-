// Fix: Implement the CourseCard component
import React from 'react';
import { Course } from '../types';
import Button from './Button';

interface CourseCardProps {
  course: Course;
  onViewCourse: (course: Course) => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, onViewCourse }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform transform hover:-translate-y-1">
      <img className="w-full h-48 object-cover" src={course.imageUrl} alt={course.title} />
      <div className="p-6">
        <span className="inline-block bg-primary-100 text-primary-800 text-xs font-semibold px-2.5 py-0.5 rounded-full mb-2">
          {course.category}
        </span>
        <h3 className="text-xl font-bold text-gray-900 mb-2 h-16">{course.title}</h3>
        <p className="text-gray-600 text-sm mb-4 h-10 overflow-hidden">{course.description}</p>
        <div className="flex justify-between items-center">
          <p className="text-lg font-bold text-primary-600">{course.price > 0 ? `${course.price} ر.س` : 'مجاني'}</p>
          <Button onClick={() => onViewCourse(course)} size="sm">
            عرض الدورة
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
