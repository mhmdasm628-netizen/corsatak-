// Fix: Implement the AppContext for state management
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, Course, Enrollment, PaymentRequest, PaymentRequestStatus, AppSettings, Permission, ForumPost, Lesson, ForumReply } from '../types';
import { mockUsers, mockCourses, mockEnrollments, mockPaymentRequests, mockSettings, mockForumPosts } from '../data/mockData';

interface AppContextType {
  user: User | null;
  courses: Course[];
  enrollments: Enrollment[];
  themeColor: string;
  setThemeColor: (color: string) => void;
  login: (credentials: { email: string, password: string }) => boolean;
  signup: (userData: { name: string, email: string, password: string }) => { success: boolean, message: string };
  logout: () => void;
  getCourseById: (id: string) => Course | undefined;
  getEnrollmentForCourse: (courseId: string) => Enrollment | undefined;
  enrollInCourse: (courseId: string) => void;
  completeLesson: (courseId: string, lessonId: string) => void;
  // Admin & permission-based functions
  hasPermission: (permission: Permission) => boolean;
  addCourse: (course: Omit<Course, 'id' | 'lessons'> & { lessons: [] }) => void;
  updateCourse: (course: Course) => void;
  deleteCourse: (courseId: string) => void;
  addLessonToCourse: (courseId: string, lessonData: Omit<Lesson, 'id'>) => void;
  updateLessonInCourse: (courseId: string, updatedLesson: Lesson) => void;
  deleteLessonFromCourse: (courseId: string, lessonId: string) => void;
  getUsers: () => User[];
  updateUserPermissions: (userId: string, permissions: Permission[]) => void;
  // Payment
  paymentRequests: PaymentRequest[];
  settings: AppSettings;
  createPaymentRequest: (courseId: string, paymentPhoneNumber: string) => void;
  updatePaymentRequestStatus: (requestId: string, status: PaymentRequestStatus) => void;
  updateVodafoneCashNumber: (newNumber: string) => void;
  // Forum
  getForumPostsForCourse: (courseId: string) => ForumPost[];
  addForumPost: (postData: { courseId: string; title: string; content: string; }) => void;
  addForumReply: (replyData: { postId: string; content: string; }) => void;
  deleteForumPost: (postId: string) => void;
  deleteForumReply: (postId: string, replyId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [courses, setCourses] = useState<Course[]>(mockCourses);
  const [enrollments, setEnrollments] = useState<Enrollment[]>(mockEnrollments);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>(mockPaymentRequests);
  const [settings, setSettings] = useState<AppSettings>(mockSettings);
  const [forumPosts, setForumPosts] = useState<ForumPost[]>(mockForumPosts);
  const [themeColor, setThemeColorState] = useState<string>('#4f46e5'); // Default Indigo

  const setThemeColor = (color: string) => {
    setThemeColorState(color);
    localStorage.setItem('themeColor', color);
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('themeColor');
    if (savedTheme) {
      setThemeColorState(savedTheme);
    }
  }, []);

  const login = (credentials: { email: string, password: string }) => {
    const foundUser = users.find(u => u.email === credentials.email && u.password === credentials.password);
    if (foundUser) {
      setUser(foundUser);
      return true;
    }
    return false;
  };

  const signup = (userData: { name: string, email: string, password: string }) => {
    if (users.some(u => u.email === userData.email)) {
      return { success: false, message: 'هذا البريد الإلكتروني مستخدم بالفعل.' };
    }
    const newUser: User = {
      id: `u${Date.now()}`,
      ...userData,
      role: 'student',
      permissions: [],
    };
    setUsers(prev => [...prev, newUser]);
    setUser(newUser);
    return { success: true, message: 'تم إنشاء الحساب بنجاخ!' };
  };

  const logout = () => {
    setUser(null);
  };

  const hasPermission = (permission: Permission) => {
    if (!user) return false;
    return user.role === 'admin' || user.permissions.includes(permission);
  }

  const getCourseById = (id: string) => {
    return courses.find(c => c.id === id);
  };

  const getEnrollmentForCourse = (courseId: string) => {
    if (!user) return undefined;
    return enrollments.find(e => e.userId === user.id && e.courseId === courseId);
  }

  const enrollInCourse = (courseId: string, userIdToEnroll?: string) => {
    const studentId = userIdToEnroll || user?.id;
    if (!studentId || enrollments.some(e => e.userId === studentId && e.courseId === courseId)) return;
    
    const newEnrollment: Enrollment = {
      userId: studentId,
      courseId,
      progress: { completedLessons: [] },
      enrollmentDate: new Date(),
    };
    setEnrollments(prev => [...prev, newEnrollment]);
  };
  
  const completeLesson = (courseId: string, lessonId: string) => {
    if (!user) return;
    setEnrollments(prev => prev.map(e => {
      if (e.userId === user.id && e.courseId === courseId) {
        if (!e.progress.completedLessons.includes(lessonId)) {
          return { ...e, progress: { ...e.progress, completedLessons: [...e.progress.completedLessons, lessonId] } };
        }
      }
      return e;
    }));
  };
  
  const createPaymentRequest = (courseId: string, paymentPhoneNumber: string) => {
    if (!user) return;
    const existingPendingRequest = paymentRequests.find(pr => pr.userId === user.id && pr.courseId === courseId && pr.status === 'pending');
    if (existingPendingRequest) return;
    const newRequest: PaymentRequest = { id: `pr${Date.now()}`, userId: user.id, courseId, paymentPhoneNumber, status: 'pending', requestDate: new Date() };
    setPaymentRequests(prev => [...prev, newRequest]);
  };

  const updatePaymentRequestStatus = (requestId: string, status: PaymentRequestStatus) => {
    if (!hasPermission('manage_courses')) return; // Simple permission check
    const request = paymentRequests.find(pr => pr.id === requestId);
    if (!request) return;
    setPaymentRequests(prev => prev.map(pr => pr.id === requestId ? { ...pr, status } : pr));
    if (status === 'approved') {
        enrollInCourse(request.courseId, request.userId);
    }
  };

  const updateVodafoneCashNumber = (newNumber: string) => {
    if (user?.role !== 'admin') return;
    setSettings(prev => ({ ...prev, vodafoneCashNumber: newNumber }));
  };

  // Admin/Permission functions
  const addCourse = (courseData: Omit<Course, 'id' | 'lessons'> & { lessons: [] }) => {
      if (!hasPermission('manage_courses')) return;
      const newCourse: Course = { id: `c${Date.now()}`, ...courseData };
      setCourses(prev => [...prev, newCourse]);
  };
  
  const updateCourse = (updatedCourse: Course) => {
      if (!hasPermission('manage_courses')) return;
      setCourses(prev => prev.map(c => c.id === updatedCourse.id ? updatedCourse : c));
  };
  
  const deleteCourse = (courseId: string) => {
      if (!hasPermission('manage_courses')) return;
      setCourses(prev => prev.filter(c => c.id !== courseId));
      setEnrollments(prev => prev.filter(e => e.courseId !== courseId));
  };
  
  const addLessonToCourse = (courseId: string, lessonData: Omit<Lesson, 'id'>) => {
    if (!hasPermission('manage_courses')) return;
    const newLesson: Lesson = { ...lessonData, id: `l${Date.now()}` };
    setCourses(prev => prev.map(c => c.id === courseId ? { ...c, lessons: [...c.lessons, newLesson] } : c));
  };

  const updateLessonInCourse = (courseId: string, updatedLesson: Lesson) => {
    if (!hasPermission('manage_courses')) return;
    setCourses(prev => prev.map(c => c.id === courseId ? { ...c, lessons: c.lessons.map(l => l.id === updatedLesson.id ? updatedLesson : l) } : c));
  };

  const deleteLessonFromCourse = (courseId: string, lessonId: string) => {
    if (!hasPermission('manage_courses')) return;
    setCourses(prev => prev.map(c => c.id === courseId ? { ...c, lessons: c.lessons.filter(l => l.id !== lessonId) } : c));
  };
  
  const getUsers = () => users;
  
  const updateUserPermissions = (userId: string, permissions: Permission[]) => {
      if (!hasPermission('manage_users')) return;
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, permissions } : u));
  };
  
  // Forum functions
  const getForumPostsForCourse = (courseId: string) => forumPosts.filter(p => p.courseId === courseId).sort((a,b) => b.createdAt.getTime() - a.createdAt.getTime());

  const addForumPost = (postData: { courseId: string; title: string; content: string; }) => {
    if (!user) return;
    const newPost: ForumPost = { ...postData, id: `p${Date.now()}`, authorId: user.id, createdAt: new Date(), replies: [] };
    setForumPosts(prev => [...prev, newPost]);
  };

  const addForumReply = (replyData: { postId: string; content: string; }) => {
    if (!user) return;
    const newReply: ForumReply = { ...replyData, id: `r${Date.now()}`, authorId: user.id, createdAt: new Date() };
    setForumPosts(prev => prev.map(p => p.id === replyData.postId ? { ...p, replies: [...p.replies, newReply] } : p));
  };
  
  const deleteForumPost = (postId: string) => {
      const post = forumPosts.find(p => p.id === postId);
      if (!user || (!hasPermission('manage_forums') && post?.authorId !== user.id)) return;
      setForumPosts(prev => prev.filter(p => p.id !== postId));
  };

  const deleteForumReply = (postId: string, replyId: string) => {
      const post = forumPosts.find(p => p.id === postId);
      const reply = post?.replies.find(r => r.id === replyId);
      if (!user || (!hasPermission('manage_forums') && reply?.authorId !== user.id)) return;
      setForumPosts(prev => prev.map(p => p.id === postId ? { ...p, replies: p.replies.filter(r => r.id !== replyId) } : p));
  };

  const value = {
    user, courses, enrollments, themeColor, setThemeColor, login, signup, logout, getCourseById, getEnrollmentForCourse, enrollInCourse,
    completeLesson, hasPermission, addCourse, updateCourse, deleteCourse, addLessonToCourse, updateLessonInCourse, deleteLessonFromCourse,
    getUsers, updateUserPermissions, paymentRequests, settings, createPaymentRequest, updatePaymentRequestStatus, updateVodafoneCashNumber,
    getForumPostsForCourse, addForumPost, addForumReply, deleteForumPost, deleteForumReply
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};